<?php 
setcookie("admin_id",'');
setcookie("user",'');
echo"<script>alert('退出成功');parent.location.href='/admin/login.php';</script>";
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>退出登录</title>
</head>

<body>
</body>
</html>