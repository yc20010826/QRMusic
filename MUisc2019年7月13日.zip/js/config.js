var apphost = "http://47.244.30.129:8081";//注册登录的接口地址
var appPayhost = "http://def.oa3jjg.cn/User_Huan_index.html";//支付地址
function GET(variable) {
       var query = window.location.search.substring(1);
       var vars = query.split("&");
       for (var i=0;i<vars.length;i++) {
               var pair = vars[i].split("=");
               if(pair[0] == variable){return pair[1];}
       }
       return(false);
}