<?php
/* *
 * 功能：彩虹易支付异步通知页面
 * 说明：
 * 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 * 该代码仅供学习和研究支付宝接口使用，只是提供一个参考。


 *************************页面功能说明*************************
 * 创建该页面文件时，请留心该页面文件中无任何HTML代码及空格。
 * 该页面不能在本机电脑测试，请到服务器上做测试。请确保外部可以访问该页面。
 * 该页面调试工具请使用写文本函数logResult，该函数已被默认关闭，见alipay_notify_class.php中的函数verifyNotify
 */

require_once("epay.config.php");
require_once("lib/epay_notify.class.php");

//计算得出通知验证结果
$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyNotify();

if($verify_result) {//验证成功
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//请在这里加上商户的业务逻辑程序代

	
	//——请根据您的业务逻辑来编写程序（以下代码仅作参考）——
	
    //获取支付宝的通知返回参数，可参考技术文档中服务器异步通知参数列表
	
	//商户订单号

	$out_trade_no = $_GET['out_trade_no'];

	//彩虹易支付交易号

	$trade_no = $_GET['trade_no'];

	//交易状态
	$trade_status = $_GET['trade_status'];

	//支付方式
	$type = $_GET['type'];
	//支付id
	$id = $_GET['name'];
	//支付金额
	$jine = $_GET['money']*10;
	$Establishpaytime = date("Y-m-d H:i:s");
	if ($_GET['trade_status'] == 'TRADE_SUCCESS') {
		//判断该笔订单是否在商户网站中已经做过处理
			//如果没有做过处理，根据订单号（out_trade_no）在商户网站的订单系统中查到该笔订单的详细，并执行商户的业务程序
			//请务必判断请求时的total_fee、seller_id与通知时获取的total_fee、seller_id为一致的
			//如果有做过处理，不执行商户的业务程序
				
		//注意：
		//付款完成后，支付宝系统发送该交易状态通知

    }

	//——请根据您的业务逻辑来编写程序（以上代码仅作参考）——
    @include_once("../system/database.php");
    @include_once("../system/webquery.php");
		getConnect();
		if($id==''|| empty($id)){
			echo "支付成功但出现了错误，请联系管理员补款<br />";
		}else{
			$sql = mysql_fetch_assoc(mysql_query("select * from yc_users where id='$id'"));
			$state = mysql_fetch_assoc(mysql_query("select * from yc_paylist where orderid='$out_trade_no'"));
			if($state['state']==='1'){
				echo "该笔交易已做过处理，请不要重复操作！";
			}else{
				$Jurisdiction=$sql['Jurisdiction']+$jine;
				$xg = "update yc_users set Jurisdiction='$Jurisdiction' where id='$id'";
				$log ="update yc_paylist set Completiontime='$Establishpaytime',paystate='通过异步支付回调充值成功',state='1',trade_no='$trade_no',type='$type' where orderid='$out_trade_no'";
				if(false!==mysql_query($log)){ 
					if(false!==mysql_query($xg)){ 
						echo "异步处理补单通知成功！";
					 }else{
						echo "支付成功但出现了错误，请联系管理员补款，原因：入账失败"; 
					 }
				 }else{
					echo "支付成功但出现了记录入库失败，请联系管理员补款，原因：支付记录失败"; 
				 }
			}
		};    
	//echo "success";		//请不要修改或删除
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
}
else {
    //验证失败
    echo "fail";
}
?>