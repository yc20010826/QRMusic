﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />
	<title>卡付通支付网关</title>
</head>
<?php
/* *
 * 功能：即时到账交易接口接入页
 * 
 * 以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 * 该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 */
include_once("../system/webquery.php");
require_once("epay.config.php");
require_once("lib/epay_submit.class.php");
include_once("../system/database.php");
/**************************请求参数**************************/
        $notify_url = "http://$url/pay/notify_url.php";
        //需http://格式的完整路径，不能加?id=123这类自定义参数

        //页面跳转同步通知页面路径
        $return_url = "http://$url/pay/return_url.php";
        //需http://格式的完整路径，不能加?id=123这类自定义参数，不能写成http://localhost/

        //商户订单号
        $out_trade_no = $_POST['WIDout_trade_no'];
        //商户网站订单系统中唯一订单号，必填
		
		//支付方式
        @$type = $_POST['type'];
        //商品名称
        $name = $_POST['WIDsubject'];
        @$username = $_POST['username'];
        @$Establishpaytime = date("Y-m-d H:i:s");
		//付款金额
        $money = $_POST['WIDtotal_fee'];
		//站点名称
        $sitename = "网站交互平台";
        //必填

        //订单描述
			if($_POST['WIDtotal_fee'] == ''||$_POST['WIDtotal_fee'] ==null||$_POST['WIDtotal_fee'] ==0){
				echo "金额不能为空，请重新输入整数"; 
			}else{
				getConnect();
				$query = "select * from yc_paylist where orderid=$out_trade_no";
				$zhixing = mysql_query($query);
				if(mysql_num_rows($zhixing)>=1){
					echo "该单号已有记录，请重新下单！"; 
				}else{
					$log="insert into yc_paylist values(null, '$name', '$username', '$out_trade_no',null, '$money',null,'$Establishpaytime','0000-00-00 00:00:00','等待支付','0')";
					if(false!==mysql_query($log)){ 
						//构造要请求的参数数组，无需改动
						$parameter = array(
							"pid" => trim($alipay_config['partner']),
							"type" => $type,
							"notify_url"	=> $notify_url,
							"return_url"	=> $return_url,
							"out_trade_no"	=> $out_trade_no,
							"name"	=> $name,
							"money"	=> $money,
							"sitename"	=> $sitename
						);

						//建立请求
						$alipaySubmit = new AlipaySubmit($alipay_config);
						$html_text = $alipaySubmit->buildRequestForm($parameter);
						echo $html_text;
					}else{
						echo "记录订单失败，请重新操作"; 
					}
				}
			}

/************************************************************/

?>
</body>
</html>