<?php
@include_once("../system/database.php");
getConnect();
@$uid = $_POST['uid'];
$down= mysql_fetch_assoc(mysql_query("select Jurisdiction from yc_users where id='$uid'"));
@$Jurisdiction=$down['Jurisdiction'];
closeConnect();
echo $Jurisdiction;
?>