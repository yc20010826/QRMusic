<?php 
include_once("../system/database.php");
include_once("../system/webquery.php");
getConnect();
if($_POST['email'] == ''||$_POST['password'] == ''){
	echo "用户名密码不能为空";
}else{
	@$username=$_POST['email'];
	@$password=md5($_POST['password']);
	$login="select * from yc_users where username='$username'";
	 if(false!==mysql_query($login)){ 
		 $sql = mysql_fetch_assoc(mysql_query($login));
		 if($password === $sql['password']){
			if($sql['state']!='1'){
				echo "账户已被封禁";  
			}else{
				$maid = md5($sql['id']+$FloatingKey);
				$uid = $sql['id'];
				$Full_name = $sql['Full_name'];
				$username1 = $sql['username'];
				echo "登录成功";
				echo"<script>sessionStorage.setItem('token', '$maid');sessionStorage.setItem('username', '$username1');sessionStorage.setItem('Full_name', '$Full_name');sessionStorage.setItem('uid', '$uid');</script>";
			}
		 }else{
			echo "登录失败";  
		 }
	 }else{
		echo "登录失败"; 
	 }
}
?>