<?php 
include_once("../system/database.php");
include_once("../system/webquery.php");
getConnect();
if($_POST['email'] == ''||$_POST['password'] == ''){
	echo "用户名密码不能为空";
}else{
	$username=$_POST['email'];
	$user = mysql_query("select * from yc_users where email='$username'");
	if (mysql_num_rows($user) > 0) {
		echo("邮箱已被占用，请更换其他邮箱！");
	}else{
		$phone=$_POST['phone'];
		$password=md5($_POST['password']);
		$login="insert into yc_users values(null, '请完善资料', '$username', '$password', '$regDownNum','$phone','$username','未填写','0','1')";
		 if(false!==mysql_query($login)){ 
			echo "注册成功，请登录！";
		 }else{
			echo "注册失败"; 
		 }
	}
}
?>