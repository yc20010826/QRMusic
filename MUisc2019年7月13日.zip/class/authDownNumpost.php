/**************************************************
 * 音乐程序后台
 * 播放器主功能模块
 * 编写：杨成
 * 时间：2019年7月12日
 *************************************************/
// 权限功能配置
<?php 
@include_once("../system/database.php");
getConnect();
$query = "select authDownNum from yc_config where id=1";
$weby = mysql_query($query);
$web = mysql_fetch_assoc($weby);
if($weby){
	$wzcDownNum = $web['authDownNum'];
	echo $wzcDownNum;
}else{
	echo 0;
}
?>