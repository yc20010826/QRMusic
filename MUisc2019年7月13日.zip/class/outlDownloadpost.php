<?php
@include_once("../system/database.php");
getConnect();
@$uid = $_POST['uid'];
$down= mysql_fetch_assoc(mysql_query("select Jurisdiction from yc_users where id='$uid'"));
if($down['Jurisdiction']<1){
	echo"余额点不足，禁止下载";
}else{
	@$Jurisdiction=$down['Jurisdiction']-1;
	if(false!==mysql_query("update yc_users set Jurisdiction='$Jurisdiction' where id='$uid'")){
		echo"开始下载";
	}else{
		echo"系统错误";
	}
	closeConnect();
}
?>