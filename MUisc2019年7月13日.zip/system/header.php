<ul class="layui-nav layui-bg-blue" lay-filter="">
	  <li class="layui-nav-item"><a href="">首页</a></li>
	  <li class="layui-nav-item">
		<a href="javascript:;">网站</a>
		<dl class="layui-nav-child"> <!-- 二级菜单 -->
		  <dd><a href="">基本信息</a></dd>
		  <dd><a href="">支付接口</a></dd>
		  <dd><a href="">采集接口</a></dd>
		  <dd><a href="">邮件配置</a></dd>
		</dl>
	  </li>
	  <li class="layui-nav-item">
		<a href="javascript:;">会员</a>
		<dl class="layui-nav-child"> <!-- 二级菜单 -->
		  <dd><a href="">会员账号</a></dd>
		  <dd><a href="">会员增加</a></dd>
		  <dd><a href="">短信通知</a></dd>
		</dl>
	  </li>
	  <li class="layui-nav-item">
		<a href="javascript:;">其他</a>
		<dl class="layui-nav-child"> <!-- 二级菜单 -->
		  <dd><a href="">移动模块</a></dd>
		  <dd><a href="">后台模版</a></dd>
		  <dd><a href="">电商平台</a></dd>
		</dl>
	  </li>
	  <li class="layui-nav-item">
		<a href="javascript:;">支持</a>
		<dl class="layui-nav-child"> <!-- 二级菜单 -->
		  <dd><a href="">售后服务</a></dd>
		  <dd><a href="">联系官方</a></dd>
		  <dd><a href="">关于开发</a></dd>
		</dl>
	  </li>
	  <li class="layui-nav-item" style="float: right;margin-right: 30px;">
		<img src="//t.cn/RCzsdCq" class="layui-nav-img">我的
		<dl class="layui-nav-child">
		  <dd><a href="javascript:;">修改信息</a></dd>
		  <dd><a href="javascript:;">安全管理</a></dd>
		  <dd><a href="javascript:;">退出登录</a></dd>
		</dl>
	  </li>
	</ul>