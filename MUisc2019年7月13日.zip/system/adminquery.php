<?php
if($_COOKIE['user'] == ''){
	$userid='1';
	@include_once("database.php");
	getConnect();
	@$web = mysql_fetch_assoc(mysql_query("select * from yc_admin where id='$userid'"));
	@$Full_name = $web['Full_name'];
	@$username = $web['username'];
	@$qq = $web['qq'];
	@$email = $web['email'];
	@$phone = $web['phone'];
	@$Jurisdiction = $web['Jurisdiction'];
	@$state = $web['state'];	
	closeConnect();
}else{
	$userid=$_COOKIE['user'];
	@include_once("database.php");
	getConnect();
	@$web = mysql_fetch_assoc(mysql_query("select * from yc_admin where id='$userid'"));
	@$Full_name = $web['Full_name'];
	@$username = $web['username'];
	@$qq = $web['qq'];
	@$email = $web['email'];
	@$phone = $web['phone'];
	@$Jurisdiction = $web['Jurisdiction'];
	@$state = $web['state'];	
	closeConnect();
}
?>