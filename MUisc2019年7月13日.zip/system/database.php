<?php
   $databaseConnection = null;
   function getConnect() {
     $hosthome = "localhost";
     $database = "music";
     $userName = "root";
     $password = "root";
     global $databaseConnection;
     $databaseConnection = @mysql_connect($hosthome, $userName, $password) or die (mysql_error());
     mysql_query("set names utf-8");
     @mysql_select_db($database, $databaseConnection) or die (mysql_error());
    }//数据库连接字符串

   function closeConnect() {
       global $databaseConnection;
       if ($databaseConnection){
         @mysql_close($databaseConnection) or die (mysql_error());
        }
   }//关闭数据库连接
?>