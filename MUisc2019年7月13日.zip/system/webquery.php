<?php
$version = '2.0.1';
@include_once("database.php");
getConnect();
$query = "select * from yc_config where id=1";
$weby = mysql_query($query);
$web = mysql_fetch_assoc($weby);
@$url=$web['url'];
@$title=$web['title'];
@$description=$web['description'];
@$keywords=$web['keywords'];
@$Contact_QQ=$web['Contact_QQ'];
@$copyright=$web['copyright'];
@$icp=$web['icp'];
@$SecurityKey = $web['SecurityKey'];//安全密匙（生成cookie验证md5关键密匙），建议在正式发布程序后固定，否则每次改动会将在线人员全部强制下线
@$FloatingKey = $web['FloatingKey'];//浮动密匙（生成cookie关键密匙）
@$payurl = $web['payurl'];
@$payid = $web['payid'];
@$paykey = $web['paykey'];
@$dkh= $web['paytransport'];
@$wzcDownNum= $web['authDownNum'];
@$regDownNum= $web['regDownNum'];
@$cache= $web['cache'];
if($web['paytransport'] == '443'){
	@$paytransport = 'https';
}else{
	@$paytransport = 'http';
}


$emaily = mysql_query("select * from yc_emailconfig where id=1");
$email = mysql_fetch_assoc($emaily);
$smtp_server=$email['smtp_server'];
$cache=$email['cache'];
$send_email=$email['send_email'];
$send_nickname=$email['send_nickname'];
$send_nickpassword	=$email['send_nickpassword'];


closeConnect();
?>