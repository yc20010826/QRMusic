<div class="footer">
		<p><?php echo $icp?></p>
	   <p><?php echo $copyright?></p>
</div>