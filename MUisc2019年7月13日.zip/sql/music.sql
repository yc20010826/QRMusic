-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2019 年 07 月 11 日 22:50
-- 服务器版本: 5.5.53
-- PHP 版本: 5.4.45

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `music`
--

-- --------------------------------------------------------

--
-- 表的结构 `yc_admin`
--

CREATE TABLE IF NOT EXISTS `yc_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `Full_name` text NOT NULL COMMENT '真实姓名',
  `username` text NOT NULL COMMENT '用户名',
  `password` text NOT NULL COMMENT '密码',
  `Jurisdiction` text NOT NULL COMMENT '权限',
  `phone` text COMMENT '手机号',
  `email` text COMMENT '邮箱号',
  `qq` text COMMENT 'QQ号码',
  `balance` int(11) NOT NULL COMMENT '余额',
  `state` int(11) NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='管理员' AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `yc_admin`
--

INSERT INTO `yc_admin` (`id`, `Full_name`, `username`, `password`, `Jurisdiction`, `phone`, `email`, `qq`, `balance`, `state`) VALUES
(1, '管理员', 'admin', 'e10adc3949ba59abbe56e057f20f883e', '1', '188888888888', '1991361342@qq.com', '1991361342', 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `yc_config`
--

CREATE TABLE IF NOT EXISTS `yc_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id号',
  `url` text COMMENT '网站地址',
  `title` text COMMENT '网站名称',
  `description` text COMMENT 'SEO简介',
  `keywords` text COMMENT 'SEO关键字',
  `Contact_QQ` text COMMENT '站长QQ',
  `copyright` text COMMENT '底部版权',
  `icp` text COMMENT 'icp备案信息',
  `SecurityKey` text COMMENT '安全密匙',
  `FloatingKey` text COMMENT '浮动密匙',
  `payurl` text NOT NULL COMMENT '支付网关地址',
  `payid` text NOT NULL COMMENT '支付网关收单id',
  `paykey` text NOT NULL COMMENT '支付网关收单key',
  `paytransport` int(11) NOT NULL COMMENT '支付端口号',
  `authDownNum` int(11) NOT NULL COMMENT '非会员每天下载',
  `regDownNum` int(11) NOT NULL COMMENT '注册赠送下载',
  `cache` varchar(5) DEFAULT 'false' COMMENT '网站缓存',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='系统表' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `yc_config`
--

INSERT INTO `yc_config` (`id`, `url`, `title`, `description`, `keywords`, `Contact_QQ`, `copyright`, `icp`, `SecurityKey`, `FloatingKey`, `payurl`, `payid`, `paykey`, `paytransport`, `authDownNum`, `regDownNum`, `cache`) VALUES
(1, '127.0.0.1', '千软音乐聚合播放器', '一款开源的基于网易云音乐api的在线音乐播放器。具有音乐搜索、播放、下载、歌词同步显示、个人音乐播放列表同步等功能。', '孟坤播放器,在线音乐播放器,MKOnlinePlayer,网易云音乐,音乐api,音乐播放器源代码', '1991361342', 'Copyright © 1999-2019 千软软件开发工作室.YangCheng. All rights reserved.', '暂无备案', '178463', '262362', 'http://pay.zimukj.cn/', '1001', '7iv3jI7VZa1DIDf3TdZazWw7te3Sst3a', 80, 2, 5, 'false');

-- --------------------------------------------------------

--
-- 表的结构 `yc_emailconfig`
--

CREATE TABLE IF NOT EXISTS `yc_emailconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `smtp_server` text NOT NULL COMMENT '服务器',
  `cache` text NOT NULL COMMENT '端口号',
  `send_email` text NOT NULL COMMENT '发件人邮箱',
  `send_nickname` text NOT NULL COMMENT '发件人昵称',
  `send_nickpassword` text NOT NULL COMMENT '邮箱密码',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='邮件配置' AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `yc_emailconfig`
--

INSERT INTO `yc_emailconfig` (`id`, `smtp_server`, `cache`, `send_email`, `send_nickname`, `send_nickpassword`) VALUES
(1, 'smtp.exmail.qq.com', '465', 'server@zimukj.cn', '子木科技', 'Yc20010826');

-- --------------------------------------------------------

--
-- 表的结构 `yc_paylist`
--

CREATE TABLE IF NOT EXISTS `yc_paylist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` text NOT NULL,
  `username` text NOT NULL,
  `orderid` text NOT NULL,
  `trade_no` text COMMENT 'trade_no',
  `money` text NOT NULL,
  `type` text COMMENT '支付方式',
  `Establishpaytime` datetime DEFAULT NULL COMMENT '创建订单时间',
  `Completiontime` datetime DEFAULT NULL COMMENT '完成时间',
  `paystate` text,
  `state` int(11) DEFAULT NULL COMMENT 'state',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='充值记录' AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `yc_users`
--

CREATE TABLE IF NOT EXISTS `yc_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `Full_name` text NOT NULL COMMENT '真实姓名',
  `username` text NOT NULL COMMENT '用户名',
  `password` text NOT NULL COMMENT '密码',
  `Jurisdiction` text NOT NULL COMMENT '剩余下载点',
  `phone` text COMMENT '手机号',
  `email` text COMMENT '邮箱号',
  `qq` text COMMENT 'QQ号码',
  `balance` int(11) NOT NULL COMMENT '余额',
  `state` int(11) NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='普通用户' AUTO_INCREMENT=1002 ;

--
-- 转存表中的数据 `yc_users`
--

INSERT INTO `yc_users` (`id`, `Full_name`, `username`, `password`, `Jurisdiction`, `phone`, `email`, `qq`, `balance`, `state`) VALUES
(1000, '请完善资料', '1991361342@qq.com', 'dacf3ffb62509a51556b60103b4b295e', '0', '17380287639', '1991361342@qq.com', '未填写', 0, 1),
(1001, '请完善资料', '1234562@qq.com', 'e10adc3949ba59abbe56e057f20f883e', '130', '12345678901', '1234562@qq.com', '未填写', 0, 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
