-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2019 年 07 月 10 日 15:23
-- 服务器版本: 5.5.53
-- PHP 版本: 5.4.45

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `music`
--

-- --------------------------------------------------------

--
-- 表的结构 `yc_admin`
--

CREATE TABLE IF NOT EXISTS `yc_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `Full_name` text NOT NULL COMMENT '真实姓名',
  `username` text NOT NULL COMMENT '用户名',
  `password` text NOT NULL COMMENT '密码',
  `Jurisdiction` text NOT NULL COMMENT '权限',
  `phone` text COMMENT '手机号',
  `email` text COMMENT '邮箱号',
  `qq` text COMMENT 'QQ号码',
  `balance` int(11) NOT NULL COMMENT '余额',
  `state` int(11) NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='管理员' AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- 表的结构 `yc_config`
--

CREATE TABLE IF NOT EXISTS `yc_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id号',
  `url` text COMMENT '网站地址',
  `title` text COMMENT '网站名称',
  `description` text COMMENT 'SEO简介',
  `keywords` text COMMENT 'SEO关键字',
  `Contact_QQ` text COMMENT '站长QQ',
  `copyright` text COMMENT '底部版权',
  `icp` text COMMENT 'icp备案信息',
  `SecurityKey` text COMMENT '安全密匙',
  `FloatingKey` text COMMENT '浮动密匙',
  `payurl` text NOT NULL COMMENT '支付网关地址',
  `payid` text NOT NULL COMMENT '支付网关收单id',
  `paykey` text NOT NULL COMMENT '支付网关收单key',
  `paytransport` int(11) NOT NULL COMMENT '支付端口号',
  `authDownNum` int(11) NOT NULL COMMENT '非会员每天下载',
  `regDownNum` int(11) NOT NULL COMMENT '注册赠送下载',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='系统表' AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

--
-- 表的结构 `yc_emailconfig`
--

CREATE TABLE IF NOT EXISTS `yc_emailconfig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `smtp_server` text NOT NULL COMMENT '服务器',
  `cache` text NOT NULL COMMENT '端口号',
  `send_email` text NOT NULL COMMENT '发件人邮箱',
  `send_nickname` text NOT NULL COMMENT '发件人昵称',
  `send_nickpassword` text NOT NULL COMMENT '邮箱密码',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='邮件配置' AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- 表的结构 `yc_paylist`
--

CREATE TABLE IF NOT EXISTS `yc_paylist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` text NOT NULL,
  `username` text NOT NULL,
  `orderid` text NOT NULL,
  `trade_no` text COMMENT 'trade_no',
  `money` text NOT NULL,
  `type` text COMMENT '支付方式',
  `Establishpaytime` datetime DEFAULT NULL COMMENT '创建订单时间',
  `Completiontime` datetime DEFAULT NULL COMMENT '完成时间',
  `paystate` text,
  `state` int(11) DEFAULT '0' COMMENT 'state',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='充值记录' AUTO_INCREMENT=1000 ;

-- --------------------------------------------------------

--
-- 表的结构 `yc_users`
--

CREATE TABLE IF NOT EXISTS `yc_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `Full_name` text NOT NULL COMMENT '真实姓名',
  `username` text NOT NULL COMMENT '用户名',
  `password` text NOT NULL COMMENT '密码',
  `Jurisdiction` text NOT NULL COMMENT '剩余下载点',
  `phone` text COMMENT '手机号',
  `email` text COMMENT '邮箱号',
  `qq` text COMMENT 'QQ号码',
  `balance` int(11) NOT NULL COMMENT '余额',
  `state` int(11) NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='普通用户' AUTO_INCREMENT=1000 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
